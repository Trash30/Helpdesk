#!/usr/bin/env bash
##############################################################
#  HelpDesk -- Installateur USB
#  Usage : sudo bash install.sh
#
#  Ce script fait TOUT en une seule commande :
#    1. Installe Node.js 20 + PostgreSQL 15 + Nginx + PM2
#    2. Deploie l'application pre-compilee
#    3. Restaure la base de donnees DEV
#    4. Configure Nginx pour http://192.168.102.152:5173
#    5. Demarre l'app avec PM2 (autostart au boot)
#
#  Requiert : Ubuntu 22.04, acces Internet (apt/NodeSource/pgdg)
##############################################################
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/opt/helpdesk"
LOG_FILE="/tmp/helpdesk-install.log"
NODE_VERSION="20"
PG_VERSION="15"

# Valeurs pre-configurees par build-usb-package.ps1
SERVER_IP="192.168.102.152"
SERVER_PORT="5173"
DB_NAME="helpdesk_prod"
DB_USER="helpdesk_user"
DB_PASS="E4oxVtv1AUxDUCu1N+AttUITfQpgIIkL9BIb457KH27zak0wDd/zL2eDvfVP46+a"
JWT_SECRET="dkyCkfO3qs0mqCCk2HaRxpI/4ekHSrvnYp22kFxRQiDNBbd61LdZWP7LUiriub/P"
APP_URL="http://192.168.102.152:5173"
COMPANY_NAME="HelpDesk"

# Couleurs
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

log()  { echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $*" | tee -a "$LOG_FILE"; }
ok()   { echo -e "${GREEN}  OK${NC} $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}  ! ${NC} $*" | tee -a "$LOG_FILE"; }
step() { echo -e "\n${CYAN}${BOLD}-- $* --${NC}" | tee -a "$LOG_FILE"; }
die()  { echo -e "\n${RED}${BOLD}ERREUR : $*${NC}" | tee -a "$LOG_FILE"; exit 1; }

clear
echo "============================================================"
echo "   HelpDesk -- Installation depuis cle USB"
echo "   Ubuntu 22.04 . Node.js 20 . PostgreSQL 15"
echo "============================================================"
echo ""

# -- Prerequis -----------------------------------------------
step "Verification"
[ "$(id -u)" -eq 0 ] || die "Executer en root : sudo bash install.sh"

if ! lsb_release -d 2>/dev/null | grep -qi "ubuntu"; then
    warn "OS non Ubuntu detecte -- continuer a vos risques"
fi

AVAIL_KB=$(df /opt --output=avail | tail -1)
[ "$AVAIL_KB" -ge 2097152 ] || die "Espace disque insuffisant (min 2 GB sur /opt)"
ok "Espace disque OK"

TOTAL_MB=$(awk '/MemTotal/ { print int($2/1024) }' /proc/meminfo)
[ "$TOTAL_MB" -ge 1800 ] || warn "RAM faible (${TOTAL_MB} MB) -- min recommande 2 GB"
ok "RAM : ${TOTAL_MB} MB"

curl -fsSL --connect-timeout 8 https://deb.nodesource.com/ &>/dev/null \
    || die "Pas d'acces Internet (requis pour apt/NodeSource)"
ok "Internet OK"

# -- 1. Paquets de base --------------------------------------
step "1/9 -- Paquets systeme"
apt-get update -qq
apt-get install -y -qq curl gnupg2 lsb-release ca-certificates \
    build-essential unzip 2>&1 | tee -a "$LOG_FILE"
ok "Paquets de base installes"

# -- 2. Node.js 20 via NodeSource ----------------------------
step "2/9 -- Node.js ${NODE_VERSION}"
if ! node -v 2>/dev/null | grep -q "^v${NODE_VERSION}"; then
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash - 2>&1 | tee -a "$LOG_FILE"
    apt-get install -y -qq nodejs 2>&1 | tee -a "$LOG_FILE"
    ok "Node.js $(node -v) installe"
else
    ok "Node.js $(node -v) deja present"
fi
ln -sf "$(which node)" /usr/local/bin/node 2>/dev/null || true
ln -sf "$(which npm)"  /usr/local/bin/npm  2>/dev/null || true
ln -sf "$(which npx)"  /usr/local/bin/npx  2>/dev/null || true

# -- 3. PostgreSQL 15 ----------------------------------------
step "3/9 -- PostgreSQL ${PG_VERSION}"
if ! command -v psql &>/dev/null; then
    curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc \
        | gpg --dearmor -o /etc/apt/trusted.gpg.d/postgresql.gpg
    echo "deb [signed-by=/etc/apt/trusted.gpg.d/postgresql.gpg] \
https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" \
        > /etc/apt/sources.list.d/pgdg.list
    apt-get update -qq
    apt-get install -y -qq "postgresql-${PG_VERSION}" "postgresql-client-${PG_VERSION}" \
        2>&1 | tee -a "$LOG_FILE"
    ok "PostgreSQL ${PG_VERSION} installe"
else
    ok "PostgreSQL $(psql --version | awk '{print $3}') deja present"
fi
systemctl enable postgresql --now 2>&1 | tee -a "$LOG_FILE" || true

# -- 4. Nginx ------------------------------------------------
step "4/9 -- Nginx"
if ! command -v nginx &>/dev/null; then
    apt-get install -y -qq nginx 2>&1 | tee -a "$LOG_FILE"
    ok "Nginx installe"
else
    ok "Nginx deja present"
fi
systemctl enable nginx --now 2>&1 | tee -a "$LOG_FILE" || true

# -- 5. PM2 -------------------------------------------------
step "5/9 -- PM2"
if ! command -v pm2 &>/dev/null; then
    npm install -g pm2 2>&1 | tee -a "$LOG_FILE"
    ln -sf "$(which pm2)" /usr/local/bin/pm2 2>/dev/null || true
    ok "PM2 installe"
else
    ok "PM2 $(pm2 -v) deja present"
fi

# -- 6. Deploiement de l'application -------------------------
step "6/9 -- Deploiement de l'application"
mkdir -p "$APP_DIR/uploads/attachments" "$APP_DIR/uploads/logo" "$APP_DIR/logs"

log "Copie des fichiers..."
cp -r "$SCRIPT_DIR/app/client"               "$APP_DIR/"
cp -r "$SCRIPT_DIR/app/server"               "$APP_DIR/"
cp    "$SCRIPT_DIR/app/ecosystem.config.js"  "$APP_DIR/"

chown -R www-data:www-data "$APP_DIR/uploads" 2>/dev/null || true
chmod -R 755 "$APP_DIR/uploads"
ok "Fichiers copies dans $APP_DIR"

# -- 7. Dependances npm + client Prisma (Linux) --------------
step "7/9 -- Dependances Node.js"
cd "$APP_DIR/server"
log "npm ci (production)..."
npm ci --omit=dev 2>&1 | tee -a "$LOG_FILE"
ok "Dependances installes"

log "Generation du client Prisma (binaire Linux)..."
npx prisma generate 2>&1 | tee -a "$LOG_FILE"
ok "Client Prisma genere"

# -- 8. Base de donnees + restauration -----------------------
step "8/9 -- Base de donnees"

log "Creation de l'utilisateur PostgreSQL..."
sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" \
    | grep -q 1 \
    || sudo -u postgres psql -c \
        "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" \
        2>&1 | tee -a "$LOG_FILE"
sudo -u postgres psql -c \
    "ALTER USER $DB_USER WITH PASSWORD '$DB_PASS';" \
    2>&1 | tee -a "$LOG_FILE"

log "Creation de la base de donnees..."
sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" \
    | grep -q 1 \
    || sudo -u postgres psql -c \
        "CREATE DATABASE $DB_NAME OWNER $DB_USER;" \
        2>&1 | tee -a "$LOG_FILE"
sudo -u postgres psql -c \
    "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;" \
    2>&1 | tee -a "$LOG_FILE"
sudo -u postgres psql -d "$DB_NAME" -c \
    "GRANT ALL ON SCHEMA public TO $DB_USER;" \
    2>&1 | tee -a "$LOG_FILE"

log "Restauration du dump DEV..."
PGPASSWORD="$DB_PASS" psql \
    --host=localhost \
    --username="$DB_USER" \
    --dbname="$DB_NAME" \
    < "$SCRIPT_DIR/db/helpdesk_dev.sql" 2>&1 | tee -a "$LOG_FILE"
ok "Base de donnees restauree"

# Fichier .env
cat > "$APP_DIR/server/.env" << ENV
DATABASE_URL=postgresql://${DB_USER}:${DB_PASS}@localhost:5432/${DB_NAME}
JWT_SECRET=${JWT_SECRET}
PORT=3001
NODE_ENV=production
UPLOADS_PATH=/opt/helpdesk/uploads
APP_URL=${APP_URL}
COMPANY_NAME=${COMPANY_NAME}
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
SMTP_FROM=noreply@helpdesk.local
ENV
ok ".env cree"

# -- 9. Nginx + PM2 -----------------------------------------
step "9/9 -- Nginx et demarrage"

cp "$SCRIPT_DIR/app/nginx.conf" /etc/nginx/sites-available/helpdesk
ln -sf /etc/nginx/sites-available/helpdesk /etc/nginx/sites-enabled/helpdesk
rm -f /etc/nginx/sites-enabled/default

nginx -t 2>&1 | tee -a "$LOG_FILE" || die "Config Nginx invalide"
systemctl reload nginx
ok "Nginx configure pour http://${SERVER_IP}:${SERVER_PORT}"

log "Demarrage de l'application PM2..."
cd "$APP_DIR"
pm2 delete helpdesk-server 2>/dev/null || true
pm2 start ecosystem.config.js 2>&1 | tee -a "$LOG_FILE"
env PATH="$PATH:/usr/bin" pm2 startup systemd -u root --hp /root 2>&1 \
    | grep "sudo" | bash 2>&1 | tee -a "$LOG_FILE" || true
pm2 save 2>&1 | tee -a "$LOG_FILE"
ok "PM2 configure (autostart au boot)"

# -- Resume -------------------------------------------------
echo ""
echo "============================================================"
echo "   Installation terminee avec succes !"
echo "============================================================"
echo ""
echo "  Application : http://${SERVER_IP}:${SERVER_PORT}"
echo ""
echo "  Comptes par defaut :"
echo "    Admin : admin@helpdesk.com  / admin123"
echo "    Agent : agent1@helpdesk.com / agent123"
echo ""
echo "  IMPORTANT : changez ces mots de passe dans l'application !"
echo ""
echo "  DB  : $DB_NAME  (user: $DB_USER)"
echo "  Log : $LOG_FILE"
echo ""
echo "  Commandes utiles :"
echo "    pm2 status"
echo "    pm2 logs helpdesk-server"
echo "    systemctl status nginx"
echo ""
